write('Hello World'), nl, wirte('hello class').
