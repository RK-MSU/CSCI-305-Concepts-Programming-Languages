

fun main() {
 
    //imutable and immatuble
    //unchangable
    val name = "Hunter"    //immutable - read only variables
    var secondName = "Lloyd" //mutable
    //println(name + "     " + secondName)  //Got rid of System.out....thank you
    //type inference
    //erorrs not being used
    var bigInt: Int= Int.MAX_VALUE;
    var smallInt: Int = Int.MIN_VALUE
    println("Biggest int: " + bigInt)  //old way
    println("Smallest int: $smallInt")  //new way
    
    //other Data types
    //Long, Double, Float, Shorty, Byte, Characters
}