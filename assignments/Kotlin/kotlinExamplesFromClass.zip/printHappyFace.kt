fun main() {
   val kotlin = "🙂"
   println(kotlin)
}